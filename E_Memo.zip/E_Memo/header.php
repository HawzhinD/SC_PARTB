<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn() && basename($_SERVER['PHP_SELF']) !== 'login.php') {
    header('Location: login.php');
    exit;
}

// Get current user data if logged in
$currentUser = isLoggedIn() ? getCurrentUser() : null;
$unreadNotificationsCount = isLoggedIn() ? countUnreadNotifications($_SESSION['user_id']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' : ''; ?><?php echo $app_name; ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            padding-top: 56px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        
        .content {
            flex: 1;
        }
        
        .notification-badge {
            position: absolute;
            top: 0px;
            right: 2px;
            padding: 3px 5px;
            border-radius: 50%;
            background-color: red;
            color: white;
            font-size: 10px;
        }
        
        .sidebar {
            min-height: calc(100vh - 56px);
            background-color: #f8f9fa;
            padding-top: 15px;
        }
        
        .navbar-dark .navbar-nav .nav-link {
            color: rgba(255, 255, 255, 0.85);
        }
        
        .navbar-dark .navbar-nav .nav-link:hover {
            color: rgba(255, 255, 255, 1);
        }
    </style>

    <!-- Include these in your header.php file (before the closing </head> tag) -->

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- Or if you prefer to use local files: -->
<!-- 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
-->

<!-- Make sure the footer.php file has the following script to initialize Bootstrap components -->
<script>
  // Initialize Bootstrap tooltips
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  });
  
  // Initialize Bootstrap popovers
  var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
  var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
    return new bootstrap.Popover(popoverTriggerEl)
  });
  
  // Ensure dropdowns work by manually adding event listeners if needed
  document.addEventListener('DOMContentLoaded', function() {
    var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'))
    dropdownElementList.forEach(function(dropdownToggleEl) {
      dropdownToggleEl.addEventListener('click', function(event) {
        event.preventDefault();
        var dropdown = new bootstrap.Dropdown(dropdownToggleEl);
        dropdown.toggle();
      });
    });
  });
</script>

</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php"><?php echo $app_name; ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <?php if (isLoggedIn()): ?>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="memos.php">Memos</a>
                        </li>
                        <?php if (hasPermission('create_memo')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="create_memo.php">Create Memo</a>
                            </li>
                        <?php endif; ?>
                        <?php if (hasPermission('manage_users')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="users.php">Users</a>
                            </li>
                        <?php endif; ?>
                        <?php if (hasPermission('view_reports')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="reports.php">Reports</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link position-relative" href="notifications.php">
                                <i class="fas fa-bell"></i>
                                <?php if ($unreadNotificationsCount > 0): ?>
                                    <span class="notification-badge"><?php echo $unreadNotificationsCount; ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user"></i> <?php echo $_SESSION['full_name']; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    </nav>
    
    <div class="container-fluid content">
        <div class="row">
            <?php if (isLoggedIn()): ?>
                <div class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                    <div class="list-group">
                        <a href="index.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : ''; ?>">
                            <i class="fas fa-home"></i> Dashboard
                        </a>
                        <a href="memos.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'memos.php' ? 'active' : ''; ?>">
                            <i class="fas fa-file-alt"></i> My Memos
                        </a>
                        <?php if (hasPermission('create_memo')): ?>
                            <a href="create_memo.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'create_memo.php' ? 'active' : ''; ?>">
                                <i class="fas fa-plus"></i> Create Memo
                            </a>
                        <?php endif; ?>
                        <?php if (hasPermission('manage_users')): ?>
                            <a href="users.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : ''; ?>">
                                <i class="fas fa-users"></i> Manage Users
                            </a>
                        <?php endif; ?>
                        <?php if (hasPermission('view_reports')): ?>
                            <a href="reports.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'reports.php' ? 'active' : ''; ?>">
                                <i class="fas fa-chart-bar"></i> Reports</a>
                        <?php endif; ?>
                        <a href="notifications.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'notifications.php' ? 'active' : ''; ?>">
                            <i class="fas fa-bell"></i> Notifications
                            <?php if ($unreadNotificationsCount > 0): ?>
                                <span class="badge bg-danger float-end"><?php echo $unreadNotificationsCount; ?></span>
                            <?php endif; ?>
                        </a>
                        <a href="profile.php" class="list-group-item list-group-item-action <?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : ''; ?>">
                            <i class="fas fa-user-cog"></i> Profile
                        </a>
                    </div>
                </div>
                <div class="col-md-9 col-lg-10 p-4">
                    <?php displayFlashMessage(); ?>
            <?php else: ?>
                <div class="col-12">
            <?php endif; ?>