<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Check if user has permission to manage users
if (!hasPermission('manage_users')) {
    redirectWithMessage('index.php', 'You do not have permission to manage users', 'danger');
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if user ID is provided
    if (!isset($_POST['user_id']) || !is_numeric($_POST['user_id'])) {
        redirectWithMessage('users.php', 'Invalid user ID', 'danger');
    }
    
    $userId = (int)$_POST['user_id'];
    
    // Prevent deleting self
    if ($userId === (int)$_SESSION['user_id']) {
        redirectWithMessage('users.php', 'You cannot delete your own account', 'danger');
    }
    
    // Get user info for logging
    $stmt = $pdo->prepare("SELECT username FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    $username = $stmt->fetchColumn();
    
    if (!$username) {
        redirectWithMessage('users.php', 'User not found', 'danger');
    }
    
    try {
        $pdo->beginTransaction();
        
        // Check if user has created memos
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM memos WHERE creator_id = ?");
        $stmt->execute([$userId]);
        $hasCreatedMemos = ($stmt->fetchColumn() > 0);
        
        if ($hasCreatedMemos) {
            // If user has created memos, don't delete but deactivate instead
            $stmt = $pdo->prepare("UPDATE users SET is_active = 0 WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            // Log activity
            logActivity(
                $_SESSION['user_id'], 
                'Deactivate User', 
                "Deactivated user: $username (ID: $userId) - Has created memos"
            );
            
            $pdo->commit();
            
            redirectWithMessage('users.php', 'User has created memos and was deactivated instead of deleted', 'warning');
        } else {
            // Delete user's notifications
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            // Delete user's acknowledgments
            $stmt = $pdo->prepare("DELETE FROM acknowledgments WHERE recipient_id = ?");
            $stmt->execute([$userId]);
            
            // Delete user from memo recipients
            $stmt = $pdo->prepare("DELETE FROM memo_recipients WHERE recipient_id = ?");
            $stmt->execute([$userId]);
            
            // Delete user's logs
            $stmt = $pdo->prepare("DELETE FROM logs WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            // Finally delete the user
            $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            // Log activity
            logActivity(
                $_SESSION['user_id'], 
                'Delete User', 
                "Deleted user: $username (ID: $userId)"
            );
            
            $pdo->commit();
            
            redirectWithMessage('users.php', 'User deleted successfully', 'success');
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $errorMessage = 'Error deleting user: ' . $e->getMessage();
        redirectWithMessage('users.php', $errorMessage, 'danger');
    }
} else {
    // If not POST request, redirect to users page
    header('Location: users.php');
    exit;
}