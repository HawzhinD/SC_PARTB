<?php
// Set page title
$pageTitle = 'Notifications';

// Include header
require_once 'header.php';

// Get all notifications for the current user
$stmt = $pdo->prepare("
    SELECT n.*, m.title as memo_title 
    FROM notifications n
    LEFT JOIN memos m ON n.memo_id = m.memo_id
    WHERE n.user_id = ?
    ORDER BY n.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$notifications = $stmt->fetchAll();

// Mark all as read if requested
if (isset($_GET['mark_all_read']) && $_GET['mark_all_read'] === '1') {
    $stmt = $pdo->prepare("
        UPDATE notifications 
        SET is_read = 1, read_at = NOW() 
        WHERE user_id = ? AND is_read = 0
    ");
    $stmt->execute([$_SESSION['user_id']]);
    
    redirectWithMessage('notifications.php', 'All notifications marked as read', 'success');
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Notifications</h1>
        <?php if (count(array_filter($notifications, function($n) { return $n['is_read'] == 0; })) > 0): ?>
            <a href="notifications.php?mark_all_read=1" class="btn btn-primary">
                <i class="fas fa-check-double"></i> Mark All as Read
            </a>
        <?php endif; ?>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Notifications</h6>
        </div>
        <div class="card-body">
            <?php if (count($notifications) > 0): ?>
                <div class="list-group">
                    <?php foreach ($notifications as $notification): ?>
                        <div class="list-group-item list-group-item-action <?php echo $notification['is_read'] ? '' : 'bg-light'; ?>">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1"><?php echo $notification['message']; ?></h5>
                                <small class="text-muted"><?php echo formatDate($notification['created_at']); ?></small>
                            </div>
                            
                            <?php if ($notification['memo_id']): ?>
                                <p class="mb-1">
                                    Memo: <a href="view_memo.php?id=<?php echo $notification['memo_id']; ?>"><?php echo $notification['memo_title']; ?></a>
                                </p>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center mt-2">
                                <small class="text-muted">
                                    <?php if ($notification['is_read']): ?>
                                        <i class="fas fa-check"></i> Read on <?php echo formatDate($notification['read_at']); ?>
                                    <?php else: ?>
                                        <i class="fas fa-envelope"></i> Unread
                                    <?php endif; ?>
                                </small>
                                
                                <div>
                                    <?php if (!$notification['is_read']): ?>
                                        <button class="btn btn-sm btn-outline-primary mark-read" data-id="<?php echo $notification['notification_id']; ?>">
                                            Mark as Read
                                        </button>
                                    <?php endif; ?>
                                    
                                    <?php if ($notification['memo_id']): ?>
                                        <a href="view_memo.php?id=<?php echo $notification['memo_id']; ?>" class="btn btn-sm btn-primary">
                                            View Memo
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="text-center">No notifications found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Mark notification as read
    $('.mark-read').click(function() {
        const notificationId = $(this).data('id');
        const button = $(this);
        
        $.ajax({
            url: 'ajax_notifications.php',
            type: 'POST',
            data: {
                action: 'mark_read',
                notification_id: notificationId
            },
            success: function(response) {
                try {
                    const data = JSON.parse(response);
                    if (data.success) {
                        // Update UI
                        button.closest('.list-group-item').removeClass('bg-light');
                        button.closest('.d-flex').find('small').html('<i class="fas fa-check"></i> Read just now');
                        button.remove();
                    } else {
                        alert('Error: ' + data.message);
                    }
                } catch (e) {
                    alert('Error processing response');
                }
            },
            error: function() {
                alert('An error occurred while marking notification as read');
            }
        });
    });
});
</script>

<?php
// Include footer
require_once 'footer.php';
?>