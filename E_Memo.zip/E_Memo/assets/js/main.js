/**
 * E-Memo System Main JavaScript
 * For Qaiwan International University
 */

$(document).ready(function() {
    // Enable Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Enable Bootstrap popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });
    
    // Auto-hide alert messages after 5 seconds
    setTimeout(function() {
        $('.alert-dismissible').fadeTo(500, 0).slideUp(500, function() {
            $(this).remove();
        });
    }, 5000);
    
    // Toggle password visibility
    $('.toggle-password').click(function() {
        const input = $($(this).data('toggle'));
        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            $(this).find('i').removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            input.attr('type', 'password');
            $(this).find('i').removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });
    
    // Check for notification updates every 60 seconds
    if ($('#notification-badge').length) {
        setInterval(checkNotifications, 60000);
    }
    
    // Print memo function
    $('.print-memo').click(function(e) {
        e.preventDefault();
        window.print();
    });
    
    // Confirmation dialog for delete actions
    $('.confirm-action').click(function(e) {
        e.preventDefault();
        const message = $(this).data('message') || 'Are you sure you want to perform this action?';
        if (confirm(message)) {
            window.location = $(this).attr('href');
        }
    });
    
    // Handle memo acknowledgment via AJAX
    $('.acknowledge-memo').click(function(e) {
        e.preventDefault();
        const memoId = $(this).data('id');
        const button = $(this);
        
        $.ajax({
            url: 'acknowledge_memo.php',
            type: 'POST',
            data: {
                memo_id: memoId
            },
            success: function(response) {
                try {
                    const data = JSON.parse(response);
                    if (data.success) {
                        // Update UI
                        button.removeClass('btn-primary').addClass('btn-success');
                        button.html('<i class="fas fa-check"></i> Acknowledged');
                        button.attr('disabled', true);
                        
                        // Show success message
                        const alert = '<div class="alert alert-success alert-dismissible fade show" role="alert">' +
                                      'Memo acknowledged successfully.' +
                                      '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' +
                                      '</div>';
                        $('.content').prepend(alert);
                    } else {
                        alert('Error: ' + data.message);
                    }
                } catch (e) {
                    alert('Error processing response');
                }
            },
            error: function() {
                alert('An error occurred while acknowledging the memo');
            }
        });
    });
});

/**
 * Check for new notifications
 */
function checkNotifications() {
    $.ajax({
        url: 'ajax_notifications.php',
        type: 'POST',
        data: {
            action: 'get_count'
        },
        success: function(response) {
            try {
                const data = JSON.parse(response);
                if (data.success) {
                    // Update notification badge
                    const currentCount = parseInt($('#notification-badge').text()) || 0;
                    if (data.count > currentCount) {
                        $('#notification-badge').text(data.count);
                        // Play notification sound if count increased
                        if (currentCount > 0) {
                            playNotificationSound();
                        }
                    } else if (data.count === 0) {
                        $('#notification-badge').hide();
                    } else {
                        $('#notification-badge').text(data.count).show();
                    }
                }
            } catch (e) {
                console.error('Error parsing notification response:', e);
            }
        }
    });
}

/**
 * Play notification sound
 */
function playNotificationSound() {
    // Create audio element for notification sound
    const audio = new Audio('assets/sounds/notification.mp3');
    audio.play().catch(e => {
        // Browser may block autoplay without user interaction
        console.log('Auto-play was prevented:', e);
    });
}

/**
 * Format date for display
 * @param {string} dateString - The date string to format
 * @param {string} format - The desired format (optional)
 * @returns {string} Formatted date string
 */
function formatDate(dateString, format = 'd M Y, h:i A') {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return 'Invalid Date';
    
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'short' });
    const year = date.getFullYear();
    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    hours = hours % 12;
    hours = hours ? hours : 12; // Convert 0 to 12
    
    let result = format;
    result = result.replace('d', day);
    result = result.replace('M', month);
    result = result.replace('Y', year);
    result = result.replace('h', hours);
    result = result.replace('i', minutes);
    result = result.replace('A', ampm);
    
    return result;
}