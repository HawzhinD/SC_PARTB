<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Log the logout activity if user is logged in
if (isLoggedIn()) {
    logActivity($_SESSION['user_id'], 'Logout', 'User logged out');
}

// Destroy the session
session_start();
session_destroy();

// Redirect to login page
header('Location: login.php');
exit;