<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Check if user has permission to manage users
if (!hasPermission('manage_users')) {
    redirectWithMessage('index.php', 'You do not have permission to manage users', 'danger');
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if user ID is provided
    if (!isset($_POST['user_id']) || !is_numeric($_POST['user_id'])) {
        redirectWithMessage('users.php', 'Invalid user ID', 'danger');
    }
    
    $userId = (int)$_POST['user_id'];
    
    // Get current user data to compare
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$userId]);
    $currentUser = $stmt->fetch();
    
    if (!$currentUser) {
        redirectWithMessage('users.php', 'User not found', 'danger');
    }
    
    // Sanitize inputs
    $fullName = sanitize($_POST['full_name']);
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $roleId = (int)$_POST['role_id'];
    $department = sanitize($_POST['department'] ?? '');
    $position = sanitize($_POST['position'] ?? '');
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $password = $_POST['password']; // Don't sanitize password
    
    // Validate inputs
    $errors = [];
    
    if (empty($fullName)) {
        $errors[] = 'Full name is required';
    }
    
    if (empty($username)) {
        $errors[] = 'Username is required';
    } elseif ($username !== $currentUser['username']) {
        // Check if username already exists (only if changed)
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?");
        $stmt->execute([$username, $userId]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $errors[] = 'Username already exists';
        }
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    } elseif ($email !== $currentUser['email']) {
        // Check if email already exists (only if changed)
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ?");
        $stmt->execute([$email, $userId]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $errors[] = 'Email already exists';
        }
    }
    
    if ($roleId <= 0) {
        $errors[] = 'Please select a valid role';
    }
    
    // If no errors, update the user
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Update user data
            $data = [
                'full_name' => $fullName,
                'username' => $username,
                'email' => $email,
                'role_id' => $roleId,
                'department' => $department,
                'position' => $position,
                'is_active' => $isActive
            ];
            
            // Update password if provided
            if (!empty($password)) {
                $data['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
            }
            
            // Build update query
            $updateFields = [];
            $updateValues = [];
            
            foreach ($data as $field => $value) {
                $updateFields[] = "$field = ?";
                $updateValues[] = $value;
            }
            
            // Add user ID to values
            $updateValues[] = $userId;
            
            // Update user
            $stmt = $pdo->prepare("
                UPDATE users 
                SET " . implode(', ', $updateFields) . " 
                WHERE user_id = ?
            ");
            
            $stmt->execute($updateValues);
            
            // Log activity
            logActivity(
                $_SESSION['user_id'], 
                'Update User', 
                "Updated user: $username (ID: $userId)"
            );
            
            $pdo->commit();
            
            redirectWithMessage('users.php', 'User updated successfully', 'success');
        } catch (Exception $e) {
            $pdo->rollBack();
            $errorMessage = 'Error updating user: ' . $e->getMessage();
            redirectWithMessage('users.php', $errorMessage, 'danger');
        }
    } else {
        // Display errors
        $_SESSION['update_user_errors'] = $errors;
        $_SESSION['update_user_data'] = $_POST;
        header('Location: users.php');
        exit;
    }
} else {
    // If not POST request, redirect to users page
    header('Location: users.php');
    exit;
}