<?php
// Database configuration
$host = 'localhost';
$dbname = 'students';
$username = 'root';
$password = '';

// Application settings
$app_name = 'E-Memo System';
$app_url = 'http://localhost/student/';
$upload_dir = 'assets/uploads/attachments/';
$max_file_size = 5242880; // 5MB
$allowed_file_types = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'jpg', 'jpeg', 'png'];

// Connect to database
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Start session if it's not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}