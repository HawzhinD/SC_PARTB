<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    // If AJAX request
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        echo json_encode(['success' => false, 'message' => 'You must be logged in to acknowledge memos']);
        exit;
    }
    
    header('Location: login.php');
    exit;
}

// Handle AJAX request
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
    // Check if memo ID is provided
    if (!isset($_POST['memo_id']) || !is_numeric($_POST['memo_id'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid memo ID']);
        exit;
    }
    
    $memoId = (int)$_POST['memo_id'];
    
    // Check if user is a recipient of the memo
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM memo_recipients 
        WHERE memo_id = ? AND recipient_id = ?
    ");
    $stmt->execute([$memoId, $_SESSION['user_id']]);
    $isRecipient = (int)$stmt->fetchColumn() > 0;
    
    if (!$isRecipient) {
        echo json_encode(['success' => false, 'message' => 'You are not a recipient of this memo']);
        exit;
    }
    
    // Acknowledge the memo
    if (acknowledgeMemo($memoId, $_SESSION['user_id'])) {
        echo json_encode(['success' => true, 'message' => 'Memo acknowledged successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to acknowledge memo']);
    }
    
    exit;
}

// Handle regular form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if memo ID is provided
    if (!isset($_POST['memo_id']) || !is_numeric($_POST['memo_id'])) {
        redirectWithMessage('memos.php', 'Invalid memo ID', 'danger');
    }
    
    $memoId = (int)$_POST['memo_id'];
    $redirectUrl = isset($_POST['redirect']) ? $_POST['redirect'] : "view_memo.php?id=$memoId";
    
    // Check if user is a recipient of the memo
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM memo_recipients 
        WHERE memo_id = ? AND recipient_id = ?
    ");
    $stmt->execute([$memoId, $_SESSION['user_id']]);
    $isRecipient = (int)$stmt->fetchColumn() > 0;
    
    if (!$isRecipient) {
        redirectWithMessage('memos.php', 'You are not a recipient of this memo', 'danger');
    }
    
    // Acknowledge the memo
    if (acknowledgeMemo($memoId, $_SESSION['user_id'])) {
        redirectWithMessage($redirectUrl, 'Memo acknowledged successfully', 'success');
    } else {
        redirectWithMessage($redirectUrl, 'Failed to acknowledge memo', 'danger');
    }
}

// If no POST data, redirect to memos page
redirectWithMessage('memos.php', 'Invalid request', 'danger');