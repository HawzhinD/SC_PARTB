<?php
// Set page title
$pageTitle = 'View Memo';

// Include header
require_once 'header.php';

// Check if memo ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirectWithMessage('memos.php', 'Invalid memo ID', 'danger');
}

$memoId = (int)$_GET['id'];

// Get memo details
$memo = getMemoById($memoId);

// Check if memo exists
if (!$memo) {
    redirectWithMessage('memos.php', 'Memo not found', 'danger');
}

// Check if user has permission to view this memo
$hasAccess = false;

// Memo creator always has access
if ($memo['creator_id'] == $_SESSION['user_id']) {
    $hasAccess = true;
} else {
    // Check if user is a recipient
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM memo_recipients 
        WHERE memo_id = ? AND recipient_id = ?
    ");
    $stmt->execute([$memoId, $_SESSION['user_id']]);
    $isRecipient = (int)$stmt->fetchColumn() > 0;
    
    if ($isRecipient && $memo['status'] === 'published') {
        $hasAccess = true;
    }
}

// Deny access if user doesn't have permission
if (!$hasAccess) {
    redirectWithMessage('memos.php', 'You do not have permission to view this memo', 'danger');
}

// Get memo attachments
$attachments = getMemoAttachments($memoId);

// Get acknowledgment status if user is a recipient
$acknowledgment = null;
if ($memo['creator_id'] != $_SESSION['user_id']) {
    $stmt = $pdo->prepare("
        SELECT * FROM acknowledgments 
        WHERE memo_id = ? AND recipient_id = ?
    ");
    $stmt->execute([$memoId, $_SESSION['user_id']]);
    $acknowledgment = $stmt->fetch();
}

// Process acknowledgment if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acknowledge'])) {
    if (acknowledgeMemo($memoId, $_SESSION['user_id'])) {
        redirectWithMessage("view_memo.php?id=$memoId", 'Memo acknowledged successfully', 'success');
    } else {
        $error = 'Failed to acknowledge memo. Please try again.';
    }
}

// Get all acknowledgments if user is the creator
$acknowledgments = [];
if ($memo['creator_id'] == $_SESSION['user_id']) {
    $acknowledgments = getAcknowledgmentStatus($memoId);
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?php echo $memo['title']; ?></h1>
        <a href="memos.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Memos
        </a>
    </div>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <div class="row">
        <!-- Memo Details -->
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Memo Content</h6>
                    <span class="badge bg-<?php 
                        if ($memo['status'] === 'published') echo 'success';
                        elseif ($memo['status'] === 'draft') echo 'secondary';
                        else echo 'info';
                    ?>">
                        <?php echo ucfirst($memo['status']); ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="memo-content">
                        <?php echo nl2br($memo['content']); ?>
                    </div>
                    
                    <?php if (!empty($attachments)): ?>
                        <div class="attachments mt-4">
                            <h6>Attachments</h6>
                            <ul class="list-group">
                                <?php foreach ($attachments as $attachment): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <span>
                                            <i class="fas fa-paperclip"></i> 
                                            <?php echo $attachment['file_name']; ?>
                                        </span>
                                        <a href="<?php echo $attachment['file_path']; ?>" class="btn btn-sm btn-primary" download>
                                            <i class="fas fa-download"></i> Download
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <div class="memo-metadata mt-4">
                        <p class="text-muted mb-1">
                            <strong>From:</strong> <?php echo $memo['creator_name']; ?>
                        </p>
                        <p class="text-muted mb-1">
                            <strong>Created:</strong> <?php echo formatDate($memo['created_at']); ?>
                        </p>
                        <?php if ($memo['published_at']): ?>
                            <p class="text-muted mb-1">
                                <strong>Published:</strong> <?php echo formatDate($memo['published_at']); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($memo['creator_id'] != $_SESSION['user_id'] && $acknowledgment): ?>
                        <div class="text-center mt-4">
                            <?php if ($acknowledgment['status'] === 'acknowledged'): ?>
                                <div class="alert alert-success">
                                    <i class="fas fa-check-circle"></i> You acknowledged this memo on <?php echo formatDate($acknowledgment['ack_timestamp']); ?>
                                </div>
                            <?php else: ?>
                                <form method="POST" action="">
                                    <button type="submit" name="acknowledge" value="1" class="btn btn-primary">
                                        <i class="fas fa-check"></i> Acknowledge Memo
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if ($memo['creator_id'] == $_SESSION['user_id'] && $memo['status'] !== 'published'): ?>
                <div class="mb-4 text-center">
                    <a href="edit_memo.php?id=<?php echo $memoId; ?>" class="btn btn-info">
                        <i class="fas fa-edit"></i> Edit Memo
                    </a>
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteMemoModal">
                        <i class="fas fa-trash"></i> Delete Memo
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Acknowledgment Status (for creator only) -->
        <?php if ($memo['creator_id'] == $_SESSION['user_id'] && !empty($acknowledgments)): ?>
            <div class="col-md-4">
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Acknowledgment Status</h6>
                    </div>
                    <div class="card-body">
                        <!-- Acknowledgment Stats -->
                        <?php 
                        $totalRecipients = count($acknowledgments);
                        $acknowledgedCount = 0;
                        
                        foreach ($acknowledgments as $ack) {
                            if ($ack['status'] === 'acknowledged') {
                                $acknowledgedCount++;
                            }
                        }
                        
                        $acknowledgedPercent = $totalRecipients > 0 ? ($acknowledgedCount / $totalRecipients) * 100 : 0;
                        ?>
                        
                        <div class="text-center mb-3">
                            <h4><?php echo $acknowledgedCount; ?> of <?php echo $totalRecipients; ?> acknowledged</h4>
                            <div class="progress">
                                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $acknowledgedPercent; ?>%"
                                     aria-valuenow="<?php echo $acknowledgedPercent; ?>" aria-valuemin="0" aria-valuemax="100">
                                    <?php echo round($acknowledgedPercent); ?>%
                                </div>
                            </div>
                        </div>
                        
                        <!-- Recipient List -->
                        <div class="recipient-list">
                            <ul class="list-group">
                                <?php foreach ($acknowledgments as $ack): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <span><?php echo $ack['full_name']; ?></span>
                                        <?php if ($ack['status'] === 'acknowledged'): ?>
                                            <span class="badge bg-success rounded-pill">
                                                <i class="fas fa-check"></i> <?php echo formatDate($ack['ack_timestamp'], 'd M, H:i'); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-warning rounded-pill">
                                                <i class="fas fa-clock"></i> Pending
                                            </span>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        
                        <!-- Reminder Button -->
                        <?php if ($acknowledgedCount < $totalRecipients): ?>
                            <div class="text-center mt-3">
                                <button type="button" class="btn btn-warning" id="sendReminders" data-id="<?php echo $memoId; ?>">
                                    <i class="fas fa-bell"></i> Send Reminders
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Memo Confirmation Modal -->
<?php if ($memo['creator_id'] == $_SESSION['user_id']): ?>
    <div class="modal fade" id="deleteMemoModal" tabindex="-1" aria-labelledby="deleteMemoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteMemoModalLabel">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this memo? This action cannot be undone.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" action="delete_memo.php">
                        <input type="hidden" name="memo_id" value="<?php echo $memoId; ?>">
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
$(document).ready(function() {
    // Send reminders function
    $('#sendReminders').click(function() {
        const memoId = $(this).data('id');
        
        $.ajax({
            url: 'ajax_notifications.php',
            type: 'POST',
            data: {
                action: 'send_reminders',
                memo_id: memoId
            },
            success: function(response) {
                const data = JSON.parse(response);
                if (data.success) {
                    alert('Reminders sent successfully!');
                } else {
                    alert('Error sending reminders: ' + data.message);
                }
            },
            error: function() {
                alert('An error occurred while sending reminders.');
            }
        });
    });
});
</script>

<?php
// Include footer
require_once 'footer.php';
?>