<?php
// Set page title
$pageTitle = 'Manage Users';

// Include header
require_once 'header.php';

// Check if user has permission to manage users
if (!hasPermission('manage_users')) {
    redirectWithMessage('index.php', 'You do not have permission to manage users', 'danger');
}

// Get all users
$users = getAllUsers();

// Get all roles
$roles = getAllRoles();
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Manage Users</h1>
        <a href="create_user.php" class="btn btn-primary">
            <i class="fas fa-user-plus"></i> Create New User
        </a>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Users</h6>
            <div class="input-group" style="width: 300px;">
                <input type="text" class="form-control" placeholder="Search users..." id="userSearch">
                <button class="btn btn-outline-secondary" type="button">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="usersTable">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['full_name']; ?></td>
                                <td><?php echo $user['username']; ?></td>
                                <td><?php echo $user['email']; ?></td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $user['role_id'] == 1 ? 'danger' : 
                                            ($user['role_id'] == 2 ? 'primary' : 'success'); 
                                    ?>">
                                        <?php echo $user['role_name']; ?>
                                    </span>
                                </td>
                                <td><?php echo $user['department'] ?? 'N/A'; ?></td>
                                <td><?php echo $user['last_login'] ? formatDate($user['last_login']) : 'Never'; ?></td>
                                <td>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-info edit-user" 
                                                data-id="<?php echo $user['user_id']; ?>"
                                                data-name="<?php echo $user['full_name']; ?>"
                                                data-username="<?php echo $user['username']; ?>"
                                                data-email="<?php echo $user['email']; ?>"
                                                data-role="<?php echo $user['role_id']; ?>"
                                                data-department="<?php echo $user['department'] ?? ''; ?>"
                                                data-position="<?php echo $user['position'] ?? ''; ?>"
                                                data-active="<?php echo $user['is_active']; ?>">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        
                                        <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                                            <button type="button" class="btn btn-sm btn-danger delete-user" 
                                                    data-id="<?php echo $user['user_id']; ?>"
                                                    data-name="<?php echo $user['full_name']; ?>">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editUserForm" action="update_user.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="user_id" id="edit_user_id">
                    
                    <div class="mb-3">
                        <label for="edit_full_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="edit_full_name" name="full_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="edit_username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="edit_password" name="password" placeholder="Leave blank to keep current password">
                        <div class="form-text">Only fill this if you want to change the password.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_role_id" class="form-label">Role</label>
                        <select class="form-select" id="edit_role_id" name="role_id" required>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo $role['role_id']; ?>"><?php echo $role['role_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_department" class="form-label">Department</label>
                        <input type="text" class="form-control" id="edit_department" name="department">
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_position" class="form-label">Position</label>
                        <input type="text" class="form-control" id="edit_position" name="position">
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="edit_is_active" name="is_active" value="1">
                        <label class="form-check-label" for="edit_is_active">Active</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteUserModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete <span id="deleteUserName"></span>? This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteUserForm" action="delete_user.php" method="POST">
                    <input type="hidden" name="user_id" id="delete_user_id">
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Search functionality
    $("#userSearch").on("keyup", function() {
        const value = $(this).val().toLowerCase();
        $("#usersTable tbody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
    
    // Edit user modal
    $('.edit-user').click(function() {
        const userId = $(this).data('id');
        const fullName = $(this).data('name');
        const username = $(this).data('username');
        const email = $(this).data('email');
        const roleId = $(this).data('role');
        const department = $(this).data('department');
        const position = $(this).data('position');
        const isActive = $(this).data('active');
        
        $('#edit_user_id').val(userId);
        $('#edit_full_name').val(fullName);
        $('#edit_username').val(username);
        $('#edit_email').val(email);
        $('#edit_role_id').val(roleId);
        $('#edit_department').val(department);
        $('#edit_position').val(position);
        $('#edit_is_active').prop('checked', isActive == 1);
        
        $('#editUserModal').modal('show');
    });
    
    // Delete user modal
    $('.delete-user').click(function() {
        const userId = $(this).data('id');
        const userName = $(this).data('name');
        
        $('#delete_user_id').val(userId);
        $('#deleteUserName').text(userName);
        
        $('#deleteUserModal').modal('show');
    });
});
</script>

<?php
// Include footer
require_once 'footer.php';
?>