<?php
// Include database connection
require_once 'config.php';

/**
 * Authentication Functions
 */

// Check if a user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Check if the current user has a specific permission
function hasPermission($permission) {
    if (!isLoggedIn() || !isset($_SESSION['permissions'])) {
        return false;
    }
    
    $permissions = $_SESSION['permissions'];
    return isset($permissions[$permission]) && $permissions[$permission] === true;
}

// Get the current logged-in user data
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    
    return getUserById($_SESSION['user_id']);
}

// Get user by ID
function getUserById($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT u.*, r.role_name, r.permissions 
        FROM users u 
        JOIN roles r ON u.role_id = r.role_id 
        WHERE u.user_id = ?
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if ($user) {
        $user['permissions'] = json_decode($user['permissions'], true);
    }
    
    return $user;
}

// Get all users
function getAllUsers() {
    global $pdo;
    
    $stmt = $pdo->query("
        SELECT u.*, r.role_name 
        FROM users u 
        JOIN roles r ON u.role_id = r.role_id 
        ORDER BY u.full_name
    ");
    
    return $stmt->fetchAll();
}

// Get users by role
function getUsersByRole($roleId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT * FROM users 
        WHERE role_id = ? 
        ORDER BY full_name
    ");
    $stmt->execute([$roleId]);
    
    return $stmt->fetchAll();
}

// Authenticate user
function authenticateUser($username, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if (!$user) {
        return false;
    }
    
    if (password_verify($password, $user['password_hash'])) {
        // Update last login
        $stmt = $pdo->prepare("
            UPDATE users 
            SET last_login = NOW() 
            WHERE user_id = ?
        ");
        $stmt->execute([$user['user_id']]);
        
        // Log activity
        logActivity($user['user_id'], 'Login', 'User logged in successfully');
        
        return $user;
    }
    
    return false;
}

/**
 * Memo Functions
 */

// Get all memos with optional filters
function getMemos($filters = []) {
    global $pdo;
    
    $sql = "
        SELECT m.*, u.full_name as creator_name 
        FROM memos m
        JOIN users u ON m.creator_id = u.user_id
    ";
    
    $params = [];
    $whereClauses = [];
    
    // Apply filters
    if (!empty($filters)) {
        if (isset($filters['status']) && $filters['status']) {
            $whereClauses[] = "m.status = ?";
            $params[] = $filters['status'];
        }
        
        if (isset($filters['creator_id']) && $filters['creator_id']) {
            $whereClauses[] = "m.creator_id = ?";
            $params[] = $filters['creator_id'];
        }
        
        if (isset($filters['search']) && $filters['search']) {
            $whereClauses[] = "(m.title LIKE ? OR m.content LIKE ?)";
            $params[] = "%{$filters['search']}%";
            $params[] = "%{$filters['search']}%";
        }
    }
    
    if (count($whereClauses) > 0) {
        $sql .= " WHERE " . implode(' AND ', $whereClauses);
    }
    
    $sql .= " ORDER BY m.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    return $stmt->fetchAll();
}

// Get memos for a specific user
function getMemosForUser($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT m.*, u.full_name as creator_name, a.status as ack_status 
        FROM memos m
        JOIN users u ON m.creator_id = u.user_id
        JOIN memo_recipients mr ON m.memo_id = mr.memo_id
        LEFT JOIN acknowledgments a ON m.memo_id = a.memo_id AND a.recipient_id = ?
        WHERE mr.recipient_id = ? AND m.status = 'published'
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$userId, $userId]);
    
    return $stmt->fetchAll();
}

// Get a memo by ID
function getMemoById($memoId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT m.*, u.full_name as creator_name 
        FROM memos m
        JOIN users u ON m.creator_id = u.user_id
        WHERE m.memo_id = ?
    ");
    $stmt->execute([$memoId]);
    
    return $stmt->fetch();
}

// Create a new memo
function createMemo($memoData, $recipients) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Insert memo
        $stmt = $pdo->prepare("
            INSERT INTO memos (title, content, creator_id, status, scheduled_at) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $memoData['title'],
            $memoData['content'],
            $memoData['creator_id'],
            $memoData['status'],
            $memoData['scheduled_at'] ?? null
        ]);
        
        $memoId = $pdo->lastInsertId();
        
        // Add recipients
        foreach ($recipients as $recipientId) {
            $stmt = $pdo->prepare("
                INSERT INTO memo_recipients (memo_id, recipient_id) 
                VALUES (?, ?)
            ");
            $stmt->execute([$memoId, $recipientId]);
            
            // Create acknowledgment record
            $stmt = $pdo->prepare("
                INSERT INTO acknowledgments (memo_id, recipient_id) 
                VALUES (?, ?)
            ");
            $stmt->execute([$memoId, $recipientId]);
        }
        
        // If memo is published, update published_at and send notifications
        if ($memoData['status'] === 'published') {
            $stmt = $pdo->prepare("
                UPDATE memos 
                SET published_at = NOW() 
                WHERE memo_id = ?
            ");
            $stmt->execute([$memoId]);
            
            // Send notifications to recipients
            foreach ($recipients as $recipientId) {
                createNotification(
                    $recipientId, 
                    $memoId, 
                    'new_memo', 
                    "New memo: {$memoData['title']}"
                );
            }
        }
        
        // Log activity
        logActivity(
            $memoData['creator_id'], 
            'Create Memo', 
            "Created memo: {$memoData['title']}"
        );
        
        $pdo->commit();
        return $memoId;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// Update an existing memo
function updateMemo($memoId, $memoData, $recipients = null) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Update memo
        $stmt = $pdo->prepare("
            UPDATE memos 
            SET title = ?, content = ?, status = ?, scheduled_at = ?, updated_at = NOW() 
            WHERE memo_id = ?
        ");
        $stmt->execute([
            $memoData['title'],
            $memoData['content'],
            $memoData['status'],
            $memoData['scheduled_at'] ?? null,
            $memoId
        ]);
        
        // If recipients are specified, update them
        if ($recipients !== null) {
            // Remove existing recipients
            $stmt = $pdo->prepare("DELETE FROM memo_recipients WHERE memo_id = ?");
            $stmt->execute([$memoId]);
            
            // Remove existing acknowledgments
            $stmt = $pdo->prepare("DELETE FROM acknowledgments WHERE memo_id = ?");
            $stmt->execute([$memoId]);
            
            // Add new recipients
            foreach ($recipients as $recipientId) {
                $stmt = $pdo->prepare("
                    INSERT INTO memo_recipients (memo_id, recipient_id) 
                    VALUES (?, ?)
                ");
                $stmt->execute([$memoId, $recipientId]);
                
                // Create acknowledgment record
                $stmt = $pdo->prepare("
                    INSERT INTO acknowledgments (memo_id, recipient_id) 
                    VALUES (?, ?)
                ");
                $stmt->execute([$memoId, $recipientId]);
            }
        }
        
        // If memo is published and wasn't before, update published_at and send notifications
        if ($memoData['status'] === 'published') {
            $stmt = $pdo->prepare("SELECT published_at FROM memos WHERE memo_id = ?");
            $stmt->execute([$memoId]);
            $memo = $stmt->fetch();
            
            if (!$memo['published_at']) {
                $stmt = $pdo->prepare("
                    UPDATE memos 
                    SET published_at = NOW() 
                    WHERE memo_id = ?
                ");
                $stmt->execute([$memoId]);
                
                // Get recipients
                $stmt = $pdo->prepare("
                    SELECT recipient_id 
                    FROM memo_recipients 
                    WHERE memo_id = ?
                ");
                $stmt->execute([$memoId]);
                $memoRecipients = $stmt->fetchAll();
                
                // Send notifications to recipients
                foreach ($memoRecipients as $recipient) {
                    createNotification(
                        $recipient['recipient_id'], 
                        $memoId, 
                        'new_memo', 
                        "New memo: {$memoData['title']}"
                    );
                }
            }
        }
        
        // Log activity
        logActivity(
            $memoData['creator_id'] ?? $_SESSION['user_id'], 
            'Update Memo', 
            "Updated memo: {$memoData['title']}"
        );
        
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// Delete a memo
function deleteMemo($memoId) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Get memo data for logging
        $stmt = $pdo->prepare("SELECT title, creator_id FROM memos WHERE memo_id = ?");
        $stmt->execute([$memoId]);
        $memo = $stmt->fetch();
        
        if (!$memo) {
            return false;
        }
        
        // Delete memo
        $stmt = $pdo->prepare("DELETE FROM memos WHERE memo_id = ?");
        $stmt->execute([$memoId]);
        
        // Log activity
        logActivity(
            $_SESSION['user_id'], 
            'Delete Memo', 
            "Deleted memo: {$memo['title']}"
        );
        
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Attachment Functions
 */

// Get attachments for a memo
function getMemoAttachments($memoId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT * FROM attachments 
        WHERE memo_id = ? 
        ORDER BY uploaded_at
    ");
    $stmt->execute([$memoId]);
    
    return $stmt->fetchAll();
}

// Add an attachment to a memo
function addAttachment($memoId, $file) {
    global $pdo, $upload_dir;
    
    // Generate unique filename
    $fileName = time() . '_' . basename($file['name']);
    $uploadPath = $upload_dir . $fileName;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        $stmt = $pdo->prepare("
            INSERT INTO attachments (memo_id, file_name, file_path, file_size, file_type) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $memoId,
            basename($file['name']),
            $uploadPath,
            $file['size'],
            $file['type']
        ]);
        
        return $pdo->lastInsertId();
    }
    
    return false;
}

/**
 * Acknowledgment Functions
 */

// Get acknowledgment status for a memo
function getAcknowledgmentStatus($memoId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT a.*, u.full_name 
        FROM acknowledgments a
        JOIN users u ON a.recipient_id = u.user_id
        WHERE a.memo_id = ?
    ");
    $stmt->execute([$memoId]);
    
    return $stmt->fetchAll();
}

// Acknowledge a memo
function acknowledgeMemo($memoId, $userId) {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("
            UPDATE acknowledgments 
            SET status = 'acknowledged', ack_timestamp = NOW() 
            WHERE memo_id = ? AND recipient_id = ?
        ");
        $stmt->execute([$memoId, $userId]);
        
        // Log activity
        logActivity(
            $userId, 
            'Acknowledge Memo', 
            "Acknowledged memo ID: $memoId"
        );
        
        $pdo->commit();
        return true;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/**
 * Notification Functions
 */

// Create a notification
function createNotification($userId, $memoId, $type, $message) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, memo_id, notification_type, message) 
        VALUES (?, ?, ?, ?)
    ");
    
    return $stmt->execute([$userId, $memoId, $type, $message]);
}

// Get notifications for a user
function getUserNotifications($userId, $limit = 10) {
    global $pdo;
    
    // Check if user ID is valid
    if (!$userId || !is_numeric($userId)) {
        return [];
    }
    
    // Use proper parameter binding for LIMIT clause
    $stmt = $pdo->prepare("
        SELECT n.*, m.title as memo_title 
        FROM notifications n
        LEFT JOIN memos m ON n.memo_id = m.memo_id
        WHERE n.user_id = ?
        ORDER BY n.created_at DESC
        LIMIT ?
    ");
    
    // PDO treats LIMIT parameter as string by default in some versions
    // We need to explicitly specify the parameter types
    $stmt->bindParam(1, $userId, PDO::PARAM_INT);
    $stmt->bindParam(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetchAll();
}

// Mark a notification as read
function markNotificationAsRead($notificationId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        UPDATE notifications 
        SET is_read = 1, read_at = NOW() 
        WHERE notification_id = ?
    ");
    
    return $stmt->execute([$notificationId]);
}

// Count unread notifications for a user
function countUnreadNotifications($userId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM notifications 
        WHERE user_id = ? AND is_read = 0
    ");
    $stmt->execute([$userId]);
    
    return $stmt->fetchColumn();
}

/**
 * Logging Functions
 */

// Log activity
function logActivity($userId, $action, $details = null) {
    global $pdo;
    
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;
    
    $stmt = $pdo->prepare("
        INSERT INTO logs (user_id, action, details, ip_address, user_agent) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    return $stmt->execute([$userId, $action, $details, $ipAddress, $userAgent]);
}

/**
 * Helper Functions
 */

// Sanitize input
function sanitize($input) {
    if (is_array($input)) {
        foreach ($input as $key => $value) {
            $input[$key] = sanitize($value);
        }
        return $input;
    }
    
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Format date
function formatDate($date, $format = 'd M Y, h:i A') {
    if (!$date) {
        return 'N/A';
    }
    
    $timestamp = strtotime($date);
    return date($format, $timestamp);
}

// Redirect with message
function redirectWithMessage($url, $message, $type = 'success') {
    $_SESSION['flash_message'] = [
        'message' => $message,
        'type' => $type
    ];
    
    header("Location: $url");
    exit;
}

// Display flash message
function displayFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message']['message'];
        $type = $_SESSION['flash_message']['type'];
        
        echo "<div class='alert alert-$type alert-dismissible fade show' role='alert'>
                $message
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>";
        
        unset($_SESSION['flash_message']);
    }
}

// Get all roles
function getAllRoles() {
    global $pdo;
    
    $stmt = $pdo->query("SELECT * FROM roles ORDER BY role_name");
    return $stmt->fetchAll();
}

// Create a new user
// Refactored: createUser with separation of concerns and no global dependency

function createUser($pdo, $sessionUserId, $userData) {
    try {
        $pdo->beginTransaction();

        $passwordHash = hashPassword($userData['password']);
        $userId = insertUser($pdo, $userData, $passwordHash);

        logUserCreation($pdo, $sessionUserId, $userData['username']);

        $pdo->commit();
        return $userId;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function insertUser($pdo, $userData, $passwordHash) {
    $stmt = $pdo->prepare("
        INSERT INTO users (username, password_hash, email, full_name, role_id, department, position) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $userData['username'],
        $passwordHash,
        $userData['email'],
        $userData['full_name'],
        $userData['role_id'],
        $userData['department'] ?? null,
        $userData['position'] ?? null
    ]);

    return $pdo->lastInsertId();
}

function logUserCreation($pdo, $sessionUserId, $username) {
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

    $stmt = $pdo->prepare("
        INSERT INTO logs (user_id, action, details, ip_address, user_agent) 
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $sessionUserId,
        'Create User',
        "Created user: {$username}",
        $ipAddress,
        $userAgent
    ]);
}