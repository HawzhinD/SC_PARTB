<?php
// Set page title
$pageTitle = 'Edit Memo';

// Include header
require_once 'header.php';

// Check if user has permission to create memos
if (!hasPermission('create_memo')) {
    redirectWithMessage('index.php', 'You do not have permission to edit memos', 'danger');
}

// Check if memo ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirectWithMessage('memos.php', 'Invalid memo ID', 'danger');
}

$memoId = (int)$_GET['id'];

// Get memo details
$memo = getMemoById($memoId);

// Check if memo exists
if (!$memo) {
    redirectWithMessage('memos.php', 'Memo not found', 'danger');
}

// Check if user is the creator of the memo
if ($memo['creator_id'] != $_SESSION['user_id']) {
    redirectWithMessage('memos.php', 'You can only edit memos you created', 'danger');
}

// Check if memo is published
if ($memo['status'] === 'published') {
    redirectWithMessage('memos.php', 'Published memos cannot be edited', 'danger');
}

// Get current recipients
$stmt = $pdo->prepare("SELECT recipient_id FROM memo_recipients WHERE memo_id = ?");
$stmt->execute([$memoId]);
$currentRecipients = array_column($stmt->fetchAll(), 'recipient_id');

// Get all users grouped by role
$roles = getAllRoles();
$users = [];
foreach ($roles as $role) {
    $users[$role['role_id']] = [
        'role_name' => $role['role_name'],
        'users' => getUsersByRole($role['role_id'])
    ];
}

// Get attachments
$attachments = getMemoAttachments($memoId);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $title = sanitize($_POST['title']);
    $content = sanitize($_POST['content']);
    $status = sanitize($_POST['status']);
    $recipients = isset($_POST['recipients']) ? $_POST['recipients'] : [];
    
    // Validate inputs
    $errors = [];
    
    if (empty($title)) {
        $errors[] = 'Title is required';
    }
    
    if (empty($content)) {
        $errors[] = 'Content is required';
    }
    
    if (empty($recipients)) {
        $errors[] = 'At least one recipient is required';
    }
    
    // If no errors, update the memo
    if (empty($errors)) {
        $scheduled_at = null;
        if ($status === 'scheduled' && !empty($_POST['scheduled_date'])) {
            $scheduled_at = $_POST['scheduled_date'] . ' ' . ($_POST['scheduled_time'] ?? '00:00:00');
        }
        
        $memoData = [
            'title' => $title,
            'content' => $content,
            'creator_id' => $_SESSION['user_id'],
            'status' => $status,
            'scheduled_at' => $scheduled_at
        ];
        
        try {
            // Update the memo
            updateMemo($memoId, $memoData, $recipients);
            
            // Process attachments if any
            if (isset($_FILES['attachments']) && !empty($_FILES['attachments']['name'][0])) {
                $attachments = $_FILES['attachments'];
                $attachmentCount = count($attachments['name']);
                
                for ($i = 0; $i < $attachmentCount; $i++) {
                    if ($attachments['error'][$i] === 0) {
                        $attachment = [
                            'name' => $attachments['name'][$i],
                            'type' => $attachments['type'][$i],
                            'tmp_name' => $attachments['tmp_name'][$i],
                            'error' => $attachments['error'][$i],
                            'size' => $attachments['size'][$i],
                        ];
                        
                        addAttachment($memoId, $attachment);
                    }
                }
            }
            
            redirectWithMessage('memos.php', 'Memo updated successfully', 'success');
        } catch (Exception $e) {
            $errors[] = 'Error updating memo: ' . $e->getMessage();
        }
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Edit Memo</h1>
        <div>
            <a href="view_memo.php?id=<?php echo $memoId; ?>" class="btn btn-info">
                <i class="fas fa-eye"></i> View Memo
            </a>
            <a href="memos.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Memos
            </a>
        </div>
    </div>
    
    <?php if (isset($errors) && !empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Memo Details</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-8">
                        <!-- Memo Title -->
                        <div class="mb-3">
                            <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" required
                                   value="<?php echo isset($title) ? $title : $memo['title']; ?>">
                        </div>
                        
                        <!-- Memo Content -->
                        <div class="mb-3">
                            <label for="content" class="form-label">Content <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="content" name="content" rows="8" required><?php echo isset($content) ? $content : $memo['content']; ?></textarea>
                        </div>
                        
                        <!-- Memo Status -->
                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-select" id="status" name="status">
                                <option value="draft" <?php echo $memo['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
                                <option value="published">Publish Now</option>
                                <option value="scheduled" <?php echo $memo['status'] === 'scheduled' ? 'selected' : ''; ?>>Schedule for Later</option>
                            </select>
                        </div>
                        
                        <!-- Scheduled Date/Time (shown if status is scheduled) -->
                        <div id="scheduledFields" class="mb-3 <?php echo $memo['status'] !== 'scheduled' ? 'd-none' : ''; ?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="scheduled_date" class="form-label">Scheduled Date</label>
                                    <?php
                                    $scheduledDate = '';
                                    if ($memo['scheduled_at']) {
                                        $scheduledDate = date('Y-m-d', strtotime($memo['scheduled_at']));
                                    }
                                    ?>
                                    <input type="date" class="form-control" id="scheduled_date" name="scheduled_date" 
                                           min="<?php echo date('Y-m-d'); ?>" value="<?php echo $scheduledDate; ?>">
                                </div>
                                <div class="col-md-6">
                                    <label for="scheduled_time" class="form-label">Scheduled Time</label>
                                    <?php
                                    $scheduledTime = '';
                                    if ($memo['scheduled_at']) {
                                        $scheduledTime = date('H:i', strtotime($memo['scheduled_at']));
                                    }
                                    ?>
                                    <input type="time" class="form-control" id="scheduled_time" name="scheduled_time" 
                                           value="<?php echo $scheduledTime; ?>">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Current Attachments -->
                        <?php if (!empty($attachments)): ?>
                            <div class="mb-3">
                                <label class="form-label">Current Attachments</label>
                                <ul class="list-group">
                                    <?php foreach ($attachments as $attachment): ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <span>
                                                <i class="fas fa-paperclip"></i> 
                                                <?php echo $attachment['file_name']; ?>
                                            </span>
                                            <div>
                                                <a href="<?php echo $attachment['file_path']; ?>" class="btn btn-sm btn-primary" download>
                                                    <i class="fas fa-download"></i> Download
                                                </a>
                                                <!-- Option to remove attachment could be added here -->
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Add New Attachments -->
                        <div class="mb-3">
                            <label for="attachments" class="form-label">Add New Attachments</label>
                            <input class="form-control" type="file" id="attachments" name="attachments[]" multiple>
                            <div class="form-text">You can select multiple files. Max file size: 5MB per file.</div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <!-- Recipients -->
                        <div class="mb-3">
                            <label class="form-label">Recipients <span class="text-danger">*</span></label>
                            
                            <div class="accordion" id="recipientsAccordion">
                                <?php foreach ($users as $roleId => $roleData): ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="heading<?php echo $roleId; ?>">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" 
                                                    data-bs-target="#collapse<?php echo $roleId; ?>" 
                                                    aria-expanded="false" aria-controls="collapse<?php echo $roleId; ?>">
                                                <?php echo $roleData['role_name']; ?> (<?php echo count($roleData['users']); ?>)
                                            </button>
                                        </h2>
                                        <div id="collapse<?php echo $roleId; ?>" class="accordion-collapse collapse" 
                                             aria-labelledby="heading<?php echo $roleId; ?>" data-bs-parent="#recipientsAccordion">
                                            <div class="accordion-body p-0">
                                                <div class="p-2 border-bottom">
                                                    <div class="form-check">
                                                        <input class="form-check-input select-all" type="checkbox" 
                                                               id="selectAll<?php echo $roleId; ?>" data-role="<?php echo $roleId; ?>">
                                                        <label class="form-check-label" for="selectAll<?php echo $roleId; ?>">
                                                            Select All <?php echo $roleData['role_name']; ?>
                                                        </label>
                                                    </div>
                                                </div>
                                                <ul class="list-group list-group-flush">
                                                    <?php foreach ($roleData['users'] as $user): ?>
                                                        <?php if ($user['user_id'] != $_SESSION['user_id']): // Skip current user ?>
                                                            <li class="list-group-item">
                                                                <div class="form-check">
                                                                    <input class="form-check-input user-checkbox role-<?php echo $roleId; ?>" 
                                                                           type="checkbox" name="recipients[]" 
                                                                           value="<?php echo $user['user_id']; ?>" 
                                                                           id="user<?php echo $user['user_id']; ?>"
                                                                           <?php echo in_array($user['user_id'], $currentRecipients) ? 'checked' : ''; ?>>
                                                                    <label class="form-check-label" for="user<?php echo $user['user_id']; ?>">
                                                                        <?php echo $user['full_name']; ?> 
                                                                        <small class="text-muted">(<?php echo $user['department'] ? $user['department'] : 'No Department'; ?>)</small>
                                                                    </label>
                                                                </div>
                                                            </li>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Memo
                    </button>
                    <a href="memos.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Show/hide scheduled fields based on status
    $('#status').change(function() {
        if ($(this).val() === 'scheduled') {
            $('#scheduledFields').removeClass('d-none');
        } else {
            $('#scheduledFields').addClass('d-none');
        }
    });
    
    // Select all checkboxes for a role
    $('.select-all').change(function() {
        const roleId = $(this).data('role');
        const isChecked = $(this).prop('checked');
        $(`.user-checkbox.role-${roleId}`).prop('checked', isChecked);
    });
    
    // Update select all checkbox when individual checkboxes change
    $('.user-checkbox').change(function() {
        const roleClass = $(this).attr('class').split(' ').find(cls => cls.startsWith('role-'));
        const roleId = roleClass.split('-')[1];
        const totalCheckboxes = $(`.user-checkbox.role-${roleId}`).length;
        const checkedCheckboxes = $(`.user-checkbox.role-${roleId}:checked`).length;
        
        $(`#selectAll${roleId}`).prop('checked', totalCheckboxes === checkedCheckboxes);
    });
    
    // Initialize select all checkboxes based on current selection
    $('.select-all').each(function() {
        const roleId = $(this).data('role');
        const totalCheckboxes = $(`.user-checkbox.role-${roleId}`).length;
        const checkedCheckboxes = $(`.user-checkbox.role-${roleId}:checked`).length;
        
        $(this).prop('checked', totalCheckboxes === checkedCheckboxes && totalCheckboxes > 0);
    });
});
</script>

<?php
// Include footer
require_once 'footer.php';
?>