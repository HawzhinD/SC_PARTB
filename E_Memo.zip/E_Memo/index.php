<?php
// Set page title
$pageTitle = 'Dashboard';

// Include header
require_once 'header.php';

// Get user data
$user = getCurrentUser();

// Get user's memos
$userMemos = getMemosForUser($_SESSION['user_id']);

// Get pending acknowledgments for admin users
$pendingAcknowledgments = [];
if (hasPermission('track_acknowledgment')) {
    // Get memos created by this user that have pending acknowledgments
    $stmt = $pdo->prepare("
        SELECT m.memo_id, m.title, COUNT(a.ack_id) as total_recipients,
               SUM(CASE WHEN a.status = 'acknowledged' THEN 1 ELSE 0 END) as acknowledged,
               MAX(m.created_at) as created_at
        FROM memos m
        JOIN acknowledgments a ON m.memo_id = a.memo_id
        WHERE m.creator_id = ? AND m.status = 'published'
        GROUP BY m.memo_id, m.title
        HAVING acknowledged < total_recipients
        ORDER BY m.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $pendingAcknowledgments = $stmt->fetchAll();
}

// Get recent notifications
$notifications = getUserNotifications($_SESSION['user_id'], 5);
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Dashboard</h1>
        <p class="text-muted">Welcome, <?php echo $_SESSION['full_name']; ?></p>
    </div>

    <div class="row">
        <!-- Stats Overview -->
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Unread Memos</div>
                            <?php 
                            $unreadCount = 0;
                            foreach ($userMemos as $memo) {
                                if ($memo['ack_status'] !== 'acknowledged') {
                                    $unreadCount++;
                                }
                            }
                            ?>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $unreadCount; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-envelope fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Recent Notifications</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($notifications); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-bell fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (hasPermission('create_memo')): ?>
            <div class="col-md-6 col-xl-3 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                    Created Memos</div>
                                <?php 
                                $stmt = $pdo->prepare("SELECT COUNT(*) FROM memos WHERE creator_id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                $createdMemosCount = $stmt->fetchColumn();
                                ?>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $createdMemosCount; ?></div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Total Memos</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo count($userMemos); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Recent Memos -->
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Recent Memos</h6>
                    <a href="memos.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (count($userMemos) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>From</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($userMemos, 0, 5) as $memo): ?>
                                        <tr>
                                            <td><?php echo $memo['title']; ?></td>
                                            <td><?php echo $memo['creator_name']; ?></td>
                                            <td><?php echo formatDate($memo['created_at']); ?></td>
                                            <td>
                                                <?php if ($memo['ack_status'] === 'acknowledged'): ?>
                                                    <span class="badge bg-success">Acknowledged</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning">Pending</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="view_memo.php?id=<?php echo $memo['memo_id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-center">No memos available.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Notifications and Pending Acknowledgments -->
        <div class="col-xl-4 col-lg-5">
            <!-- Recent Notifications -->
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Recent Notifications</h6>
                    <a href="notifications.php" class="btn btn-sm btn-primary">View All</a>
                </div>
                <div class="card-body">
                    <?php if (count($notifications) > 0): ?>
                        <div class="list-group">
                            <?php foreach ($notifications as $notification): ?>
                                <a href="view_memo.php?id=<?php echo $notification['memo_id']; ?>" class="list-group-item list-group-item-action <?php echo $notification['is_read'] ? '' : 'bg-light'; ?>">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1"><?php echo $notification['message']; ?></h6>
                                        <small><?php echo formatDate($notification['created_at'], 'd M'); ?></small>
                                    </div>
                                    <p class="mb-1"><?php echo $notification['memo_title'] ?? ''; ?></p>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-center">No notifications available.</p>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (hasPermission('track_acknowledgment') && count($pendingAcknowledgments) > 0): ?>
                <!-- Pending Acknowledgments -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Pending Acknowledgments</h6>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <?php foreach ($pendingAcknowledgments as $ack): ?>
                                <a href="view_memo.php?id=<?php echo $ack['memo_id']; ?>" class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1"><?php echo $ack['title']; ?></h6>
                                        <small><?php echo formatDate($ack['created_at'], 'd M'); ?></small>
                                    </div>
                                    <p class="mb-1">
                                        Acknowledged: <?php echo $ack['acknowledged']; ?> of <?php echo $ack['total_recipients']; ?>
                                    </p>
                                    <div class="progress mt-2" style="height: 5px;">
                                        <div class="progress-bar" role="progressbar" style="width: <?php echo ($ack['acknowledged'] / $ack['total_recipients']) * 100; ?>%"></div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (hasPermission('create_memo')): ?>
        <div class="row">
            <div class="col-12 mb-4">
                <div class="card shadow">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Quick Actions</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-3 col-md-6 mb-2">
                                <a href="create_memo.php" class="btn btn-primary btn-block">
                                    <i class="fas fa-plus me-2"></i> Create New Memo
                                </a>
                            </div>
                            <?php if (hasPermission('manage_users')): ?>
                                <div class="col-xl-3 col-md-6 mb-2">
                                    <a href="create_user.php" class="btn btn-success btn-block">
                                        <i class="fas fa-user-plus me-2"></i> Add New User
                                    </a>
                                </div>
                            <?php endif; ?>
                            <?php if (hasPermission('view_reports')): ?>
                                <div class="col-xl-3 col-md-6 mb-2">
                                    <a href="reports.php" class="btn btn-info btn-block">
                                        <i class="fas fa-chart-bar me-2"></i> View Reports
                                    </a>
                                </div>
                            <?php endif; ?>
                            <div class="col-xl-3 col-md-6 mb-2">
                                <a href="profile.php" class="btn btn-secondary btn-block">
                                    <i class="fas fa-user-cog me-2"></i> Update Profile
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.border-left-primary {
    border-left: 4px solid #4e73df;
}
.border-left-success {
    border-left: 4px solid #1cc88a;
}
.border-left-info {
    border-left: 4px solid #36b9cc;
}
.border-left-warning {
    border-left: 4px solid #f6c23e;
}
.btn-block {
    display: block;
    width: 100%;
}
</style>

<?php
// Include footer
require_once 'footer.php';
?>