<?php
// Set page title
$pageTitle = 'Reports';

// Include header
require_once 'header.php';

// Check if user has permission to view reports
if (!hasPermission('view_reports')) {
    redirectWithMessage('index.php', 'You do not have permission to view reports', 'danger');
}

// Get report type
$reportType = isset($_GET['type']) ? sanitize($_GET['type']) : 'overview';

// Define date ranges
$today = date('Y-m-d');
$startDate = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : date('Y-m-d', strtotime('-30 days'));
$endDate = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : $today;

// Generate report data based on report type
$reportData = [];
$chartData = [];
$chartTitle = '';
$chartLabels = [];
$chartValues = [];

switch ($reportType) {
    case 'memo_activity':
        $chartTitle = 'Memo Activity';
        
        // Get memo creation counts by date
        $stmt = $pdo->prepare("
            SELECT DATE(created_at) as date, COUNT(*) as count 
            FROM memos 
            WHERE created_at BETWEEN ? AND ? 
            GROUP BY DATE(created_at) 
            ORDER BY date
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59']);
        $memoCreationData = $stmt->fetchAll();
        
        // Get acknowledgment counts by date
        $stmt = $pdo->prepare("
            SELECT DATE(ack_timestamp) as date, COUNT(*) as count 
            FROM acknowledgments 
            WHERE ack_timestamp BETWEEN ? AND ? 
            GROUP BY DATE(ack_timestamp) 
            ORDER BY date
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59']);
        $acknowledgmentData = $stmt->fetchAll();
        
        // Prepare data for chart
        $dateRange = new DatePeriod(
            new DateTime($startDate),
            new DateInterval('P1D'),
            new DateTime($endDate . ' +1 day')
        );
        
        foreach ($dateRange as $date) {
            $dateStr = $date->format('Y-m-d');
            $formattedDate = $date->format('M d');
            
            // Find memo creation count for this date
            $memoCount = 0;
            foreach ($memoCreationData as $data) {
                if ($data['date'] === $dateStr) {
                    $memoCount = $data['count'];
                    break;
                }
            }
            
            // Find acknowledgment count for this date
            $ackCount = 0;
            foreach ($acknowledgmentData as $data) {
                if ($data['date'] === $dateStr) {
                    $ackCount = $data['count'];
                    break;
                }
            }
            
            $chartLabels[] = $formattedDate;
            $chartData[] = [
                'date' => $formattedDate,
                'memos' => $memoCount,
                'acknowledgments' => $ackCount
            ];
        }
        
        // Get summary statistics
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total_memos,
                   SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_memos,
                   SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft_memos,
                   SUM(CASE WHEN status = 'scheduled' THEN 1 ELSE 0 END) as scheduled_memos
            FROM memos
            WHERE created_at BETWEEN ? AND ?
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59']);
        $memoStats = $stmt->fetch();
        
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as total_acknowledgments
            FROM acknowledgments
            WHERE ack_timestamp BETWEEN ? AND ?
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59']);
        $ackStats = $stmt->fetch();
        
        $reportData = [
            'total_memos' => $memoStats['total_memos'] ?? 0,
            'published_memos' => $memoStats['published_memos'] ?? 0,
            'draft_memos' => $memoStats['draft_memos'] ?? 0,
            'scheduled_memos' => $memoStats['scheduled_memos'] ?? 0,
            'total_acknowledgments' => $ackStats['total_acknowledgments'] ?? 0
        ];
        break;
        
    case 'user_activity':
        $chartTitle = 'User Activity';
        
        // Get user activity data
        $stmt = $pdo->prepare("
            SELECT u.full_name, 
                   COUNT(DISTINCT m.memo_id) as created_memos,
                   COUNT(DISTINCT a.ack_id) as acknowledgments
            FROM users u
            LEFT JOIN memos m ON u.user_id = m.creator_id AND m.created_at BETWEEN ? AND ?
            LEFT JOIN acknowledgments a ON u.user_id = a.recipient_id AND a.ack_timestamp BETWEEN ? AND ?
            GROUP BY u.user_id, u.full_name
            ORDER BY created_memos DESC, acknowledgments DESC
            LIMIT 10
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59', $startDate, $endDate . ' 23:59:59']);
        $userData =$stmt->fetchAll();
        
        foreach ($userData as $user) {
            $chartLabels[] = $user['full_name'];
            $chartData[] = [
                'user' => $user['full_name'],
                'memos' => $user['created_memos'],
                'acknowledgments' => $user['acknowledgments']
            ];
        }
        
        // Get summary statistics
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT user_id) as active_users,
                   COUNT(*) as total_activity
            FROM (
                SELECT creator_id as user_id
                FROM memos
                WHERE created_at BETWEEN ? AND ?
                UNION
                SELECT recipient_id as user_id
                FROM acknowledgments
                WHERE ack_timestamp BETWEEN ? AND ?
            ) as activity
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59', $startDate, $endDate . ' 23:59:59']);
        $activityStats = $stmt->fetch();
        
        // Get total users
        $stmt = $pdo->prepare("SELECT COUNT(*) as total_users FROM users");
        $stmt->execute();
        $userCount = $stmt->fetchColumn();
        
        $reportData = [
            'active_users' => $activityStats['active_users'] ?? 0,
            'total_users' => $userCount,
            'inactive_users' => $userCount - ($activityStats['active_users'] ?? 0),
            'total_activity' => $activityStats['total_activity'] ?? 0
        ];
        break;
        
    case 'acknowledgment_rates':
        $chartTitle = 'Acknowledgment Rates';
        
        // Get acknowledgment data for published memos
        $stmt = $pdo->prepare("
            SELECT m.memo_id, m.title, 
                   COUNT(DISTINCT mr.recipient_id) as total_recipients,
                   SUM(CASE WHEN a.status = 'acknowledged' THEN 1 ELSE 0 END) as acknowledged
            FROM memos m
            JOIN memo_recipients mr ON m.memo_id = mr.memo_id
            LEFT JOIN acknowledgments a ON m.memo_id = a.memo_id AND mr.recipient_id = a.recipient_id
            WHERE m.status = 'published' AND m.published_at BETWEEN ? AND ?
            GROUP BY m.memo_id, m.title
            ORDER BY m.published_at DESC
            LIMIT 10
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59']);
        $memoData = $stmt->fetchAll();
        
        foreach ($memoData as $memo) {
            $ackRate = $memo['total_recipients'] > 0 ? 
                       round(($memo['acknowledged'] / $memo['total_recipients']) * 100) : 0;
            
            $shortTitle = strlen($memo['title']) > 30 ? 
                          substr($memo['title'], 0, 27) . '...' : $memo['title'];
            
            $chartLabels[] = $shortTitle;
            $chartData[] = [
                'memo' => $shortTitle,
                'full_title' => $memo['title'],
                'acknowledgment_rate' => $ackRate,
                'acknowledged' => $memo['acknowledged'],
                'total' => $memo['total_recipients']
            ];
        }
        
        // Get overall acknowledgment rate
        $stmt = $pdo->prepare("
            SELECT COUNT(DISTINCT mr.recipient_id) as total_recipients,
                   SUM(CASE WHEN a.status = 'acknowledged' THEN 1 ELSE 0 END) as acknowledged
            FROM memos m
            JOIN memo_recipients mr ON m.memo_id = mr.memo_id
            LEFT JOIN acknowledgments a ON m.memo_id = a.memo_id AND mr.recipient_id = a.recipient_id
            WHERE m.status = 'published' AND m.published_at BETWEEN ? AND ?
        ");
        $stmt->execute([$startDate, $endDate . ' 23:59:59']);
        $overallStats = $stmt->fetch();
        
        $overallRate = $overallStats['total_recipients'] > 0 ? 
                       round(($overallStats['acknowledged'] / $overallStats['total_recipients']) * 100) : 0;
        
        $reportData = [
            'total_recipients' => $overallStats['total_recipients'] ?? 0,
            'acknowledged' => $overallStats['acknowledged'] ?? 0,
            'pending' => ($overallStats['total_recipients'] ?? 0) - ($overallStats['acknowledged'] ?? 0),
            'overall_rate' => $overallRate
        ];
        break;
        
    default: // overview
        $chartTitle = 'System Overview';
        
        // Get memo counts per status
        $stmt = $pdo->prepare("
            SELECT status, COUNT(*) as count
            FROM memos
            GROUP BY status
        ");
        $stmt->execute();
        $memoStats = $stmt->fetchAll();
        
        $memoStatusData = [
            'published' => 0,
            'draft' => 0,
            'scheduled' => 0
        ];
        
        foreach ($memoStats as $stat) {
            $memoStatusData[$stat['status']] = $stat['count'];
        }
        
        $chartLabels = ['Published', 'Draft', 'Scheduled'];
        $chartData = [
            ['status' => 'Published', 'count' => $memoStatusData['published']],
            ['status' => 'Draft', 'count' => $memoStatusData['draft']],
            ['status' => 'Scheduled', 'count' => $memoStatusData['scheduled']]
        ];
        
        // Get role distribution
        $stmt = $pdo->prepare("
            SELECT r.role_name, COUNT(u.user_id) as count
            FROM users u
            JOIN roles r ON u.role_id = r.role_id
            GROUP BY r.role_id, r.role_name
        ");
        $stmt->execute();
        $roleStats = $stmt->fetchAll();
        
        // Get acknowledgment stats
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(a.ack_id) as total_acks,
                SUM(CASE WHEN a.status = 'acknowledged' THEN 1 ELSE 0 END) as acknowledged_count
            FROM acknowledgments a
        ");
        $stmt->execute();
        $ackStats = $stmt->fetch();
        
        // Get user count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users");
        $stmt->execute();
        $userCount = $stmt->fetchColumn();
        
        // Get memo count
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM memos");
        $stmt->execute();
        $memoCount = $stmt->fetchColumn();
        
        $reportData = [
            'total_users' => $userCount,
            'total_memos' => $memoCount,
            'published_memos' => $memoStatusData['published'],
            'draft_memos' => $memoStatusData['draft'],
            'scheduled_memos' => $memoStatusData['scheduled'],
            'total_acknowledgments' => $ackStats['total_acks'] ?? 0,
            'acknowledged_count' => $ackStats['acknowledged_count'] ?? 0,
            'role_distribution' => $roleStats
        ];
        break;
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Reports</h1>
    </div>
    
    <!-- Report Type Selection -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Select Report</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="reports.php?type=overview" class="card report-card <?php echo $reportType === 'overview' ? 'bg-light' : ''; ?>">
                        <div class="card-body text-center">
                            <div class="report-icon">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                            <h5>System Overview</h5>
                            <p class="text-muted">General statistics about the system</p>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-3 mb-3">
                    <a href="reports.php?type=memo_activity" class="card report-card <?php echo $reportType === 'memo_activity' ? 'bg-light' : ''; ?>">
                        <div class="card-body text-center">
                            <div class="report-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <h5>Memo Activity</h5>
                            <p class="text-muted">Statistics about memo creation and distribution</p>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-3 mb-3">
                    <a href="reports.php?type=user_activity" class="card report-card <?php echo $reportType === 'user_activity' ? 'bg-light' : ''; ?>">
                        <div class="card-body text-center">
                            <div class="report-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <h5>User Activity</h5>
                            <p class="text-muted">Statistics about user engagement</p>
                        </div>
                    </a>
                </div>
                
                <div class="col-md-3 mb-3">
                    <a href="reports.php?type=acknowledgment_rates" class="card report-card <?php echo $reportType === 'acknowledgment_rates' ? 'bg-light' : ''; ?>">
                        <div class="card-body text-center">
                            <div class="report-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <h5>Acknowledgment Rates</h5>
                            <p class="text-muted">Statistics about memo acknowledgments</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($reportType !== 'overview'): ?>
        <!-- Date Range Selector -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Date Range</h6>
            </div>
            <div class="card-body">
                <form method="GET" action="reports.php" class="row g-3 align-items-end">
                    <input type="hidden" name="type" value="<?php echo $reportType; ?>">
                    
                    <div class="col-md-4">
                        <label for="start_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" 
                               value="<?php echo $startDate; ?>" max="<?php echo $today; ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <label for="end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" 
                               value="<?php echo $endDate; ?>" max="<?php echo $today; ?>">
                    </div>
                    
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Apply Filter
                        </button>
                        <a href="reports.php?type=<?php echo $reportType; ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Report Content -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary"><?php echo $chartTitle; ?></h6>
            <button class="btn btn-sm btn-outline-primary" id="printReport">
                <i class="fas fa-print"></i> Print Report
            </button>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <?php if ($reportType === 'overview'): ?>
                    <!-- Overview Stats Cards -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Users</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_users']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Total Memos</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_memos']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Published Memos</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['published_memos']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-share-square fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Acknowledgments</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['acknowledged_count']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($reportType === 'memo_activity'): ?>
                    <!-- Memo Activity Stats Cards -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Memos</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_memos']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Published</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['published_memos']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-share-square fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Drafts</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['draft_memos']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-edit fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Acknowledgments</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_acknowledgments']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($reportType === 'user_activity'): ?>
                    <!-- User Activity Stats Cards -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Users</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_users']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Active Users</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['active_users']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-check fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-danger h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                            Inactive Users</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['inactive_users']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-user-times fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Total Activities</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_activity']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($reportType === 'acknowledgment_rates'): ?>
                    <!-- Acknowledgment Stats Cards -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Recipients</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['total_recipients']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Acknowledged</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['acknowledged']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Pending</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['pending']; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clock fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                            Overall Rate</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $reportData['overall_rate']; ?>%</div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-percentage fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                                <div class="progress mt-2">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo $reportData['overall_rate']; ?>%"
                                         aria-valuenow="<?php echo $reportData['overall_rate']; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Chart Canvas -->
            <div class="chart-container" style="position: relative; height:400px; width:100%">
                <canvas id="reportChart"></canvas>
            </div>
            
            <?php if ($reportType === 'overview'): ?>
                <!-- Role Distribution Table -->
                <div class="mt-4">
                    <h5>Role Distribution</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Role</th>
                                    <th>Count</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                foreach ($reportData['role_distribution'] as $role): 
                                    $percentage = ($role['count'] / $reportData['total_users']) * 100;
                                ?>
                                    <tr>
                                        <td><?php echo $role['role_name']; ?></td>
                                        <td><?php echo $role['count']; ?></td>
                                        <td><?php echo round($percentage, 2); ?>%</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if ($reportType === 'acknowledgment_rates' && !empty($chartData)): ?>
                <!-- Acknowledgment Details Table -->
                <div class="mt-4">
                    <h5>Acknowledgment Details</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Memo</th>
                                    <th>Acknowledged</th>
                                    <th>Total Recipients</th>
                                    <th>Rate</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($chartData as $item): ?>
                                    <tr>
                                        <td><?php echo $item['full_title']; ?></td>
                                        <td><?php echo $item['acknowledged']; ?></td>
                                        <td><?php echo $item['total']; ?></td>
                                        <td>
                                            <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" 
                                                     style="width: <?php echo $item['acknowledgment_rate']; ?>%"
                                                     aria-valuenow="<?php echo $item['acknowledgment_rate']; ?>" 
                                                     aria-valuemin="0" aria-valuemax="100">
                                                    <?php echo $item['acknowledgment_rate']; ?>%
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Chart.js Library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Chart Configuration
$(document).ready(function() {
    // Set chart data based on report type
    var chartType = '<?php echo $reportType; ?>';
    var chartLabels = <?php echo json_encode($chartLabels); ?>;
    var chartData = <?php echo json_encode($chartData); ?>;
    var chartConfig;
    
    // Configure chart based on report type
    switch (chartType) {
        case 'memo_activity':
            // Create line chart for memo activity
            var memoCounts = chartData.map(function(item) { return item.memos; });
            var ackCounts = chartData.map(function(item) { return item.acknowledgments; });
            
            chartConfig = {
                type: 'line',
                data: {
                    labels: chartLabels,
                    datasets: [
                        {
                            label: 'Memos Created',
                            data: memoCounts,
                            borderColor: 'rgba(78, 115, 223, 1)',
                            backgroundColor: 'rgba(78, 115, 223, 0.05)',
                            borderWidth: 2,
                            tension: 0.3,
                            fill: true
                        },
                        {
                            label: 'Acknowledgments',
                            data: ackCounts,
                            borderColor: 'rgba(28, 200, 138, 1)',
                            backgroundColor: 'rgba(28, 200, 138, 0.05)',
                            borderWidth: 2,
                            tension: 0.3,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Memo Activity Over Time'
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            };
            break;
            
        case 'user_activity':
            // Create bar chart for user activity
            var memosCounts = chartData.map(function(item) { return item.memos; });
            var acknowledgedCounts = chartData.map(function(item) { return item.acknowledgments; });
            
            chartConfig = {
                type: 'bar',
                data: {
                    labels: chartLabels,
                    datasets: [
                        {
                            label: 'Memos Created',
                            data: memosCounts,
                            backgroundColor: 'rgba(78, 115, 223, 0.8)',
                            borderWidth: 1
                        },
                        {
                            label: 'Memos Acknowledged',
                            data: acknowledgedCounts,
                            backgroundColor: 'rgba(28, 200, 138, 0.8)',
                            borderWidth: 1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Top 10 Most Active Users'
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        x: {
                            stacked: false
                        },
                        y: {
                            stacked: false,
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            };
            break;
            
        case 'acknowledgment_rates':
            // Create horizontal bar chart for acknowledgment rates
            var rates = chartData.map(function(item) { return item.acknowledgment_rate; });
            
            chartConfig = {
                type: 'bar',
                data: {
                    labels: chartLabels,
                    datasets: [{
                        label: 'Acknowledgment Rate (%)',
                        data: rates,
                        backgroundColor: function(context) {
                            const value = context.dataset.data[context.dataIndex];
                            return value < 50 ? 'rgba(246, 194, 62, 0.8)' : // warning
                                  (value < 75 ? 'rgba(54, 185, 204, 0.8)' : // info
                                  'rgba(28, 200, 138, 0.8)'); // success
                        },
                        borderWidth: 1
                    }]
                },
                options: {
                    indexAxis: 'y',
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Memo Acknowledgment Rates'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const memoIndex = context.dataIndex;
                                    const acknowledged = chartData[memoIndex].acknowledged;
                                    const total = chartData[memoIndex].total;
                                    return `${context.formattedValue}% (${acknowledged} of ${total})`;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            beginAtZero: true,
                            max: 100,
                            title: {
                                display: true,
                                text: 'Percentage (%)'
                            }
                        }
                    }
                }
            };
            break;
            
        default: // overview
            // Create pie chart for memo status distribution
            var counts = chartData.map(function(item) { return item.count; });
            
            chartConfig = {
                type: 'pie',
                data: {
                    labels: chartLabels,
                    datasets: [{
                        data: counts,
                        backgroundColor: [
                            'rgba(28, 200, 138, 0.8)',  // Published - success
                            'rgba(246, 194, 62, 0.8)',  // Draft - warning
                            'rgba(54, 185, 204, 0.8)'   // Scheduled - info
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Memo Status Distribution'
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const value = context.formattedValue;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((context.raw / total) * 100);
                                    return `${context.label}: ${value} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            };
            break;
    }
    
    // Create the chart
    var ctx = document.getElementById('reportChart').getContext('2d');
    var myChart = new Chart(ctx, chartConfig);
    
    // Print report functionality
    $('#printReport').click(function() {
        window.print();
    });
});
</script>

<?php
// Include footer
require_once 'footer.php';
?>