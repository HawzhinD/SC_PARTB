<?php
// Set page title
$pageTitle = 'Memos';

// Include header
require_once 'header.php';

// Get memos based on user role
$memos = [];
$filter = isset($_GET['filter']) ? sanitize($_GET['filter']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

if (hasPermission('create_memo')) {
    // Admins and users with create_memo permission can see all memos they created
    $stmt = $pdo->prepare("
        SELECT m.*, u.full_name as creator_name,
        (SELECT COUNT(*) FROM acknowledgments WHERE memo_id = m.memo_id) as total_recipients,
        (SELECT COUNT(*) FROM acknowledgments WHERE memo_id = m.memo_id AND status = 'acknowledged') as acknowledged
        FROM memos m
        JOIN users u ON m.creator_id = u.user_id
        WHERE m.creator_id = ?
        " . ($filter ? "AND m.status = ?" : "") . "
        " . ($search ? "AND (m.title LIKE ? OR m.content LIKE ?)" : "") . "
        ORDER BY m.created_at DESC
    ");
    
    $params = [$_SESSION['user_id']];
    if ($filter) {
        $params[] = $filter;
    }
    if ($search) {
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $stmt->execute($params);
    $memos = $stmt->fetchAll();
} else {
    // Regular users see memos assigned to them
    $stmt = $pdo->prepare("
        SELECT m.*, u.full_name as creator_name, a.status as ack_status
        FROM memos m
        JOIN users u ON m.creator_id = u.user_id
        JOIN memo_recipients mr ON m.memo_id = mr.memo_id
        LEFT JOIN acknowledgments a ON m.memo_id = a.memo_id AND a.recipient_id = ?
        WHERE mr.recipient_id = ? AND m.status = 'published'
        " . ($filter ? "AND a.status " . ($filter === 'pending' ? "!=" : "=") . " 'acknowledged'" : "") . "
        " . ($search ? "AND (m.title LIKE ? OR m.content LIKE ?)" : "") . "
        ORDER BY m.created_at DESC
    ");
    
    $params = [$_SESSION['user_id'], $_SESSION['user_id']];
    if ($search) {
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $stmt->execute($params);
    $memos = $stmt->fetchAll();
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Memos</h1>
        <?php if (hasPermission('create_memo')): ?>
            <a href="create_memo.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Create New Memo
            </a>
        <?php endif; ?>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                <?php if (hasPermission('create_memo')): ?>
                    My Created Memos
                <?php else: ?>
                    My Received Memos
                <?php endif; ?>
            </h6>
            
            <!-- Search and Filter Form -->
            <div class="d-flex">
                <div class="me-2">
                    <form class="d-flex" method="GET">
                        <input type="text" name="search" class="form-control me-2" placeholder="Search memos..." value="<?php echo $search; ?>">
                        <?php if (isset($_GET['filter'])): ?>
                            <input type="hidden" name="filter" value="<?php echo $filter; ?>">
                        <?php endif; ?>
                        <button type="submit" class="btn btn-outline-primary">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="filterDropdown">
                        <li><a class="dropdown-item <?php echo !$filter ? 'active' : ''; ?>" href="memos.php<?php echo $search ? '?search=' . urlencode($search) : ''; ?>">All</a></li>
                        <?php if (hasPermission('create_memo')): ?>
                            <li><a class="dropdown-item <?php echo $filter === 'published' ? 'active' : ''; ?>" href="memos.php?filter=published<?php echo $search ? '&search=' . urlencode($search) : ''; ?>">Published</a></li>
                            <li><a class="dropdown-item <?php echo $filter === 'draft' ? 'active' : ''; ?>" href="memos.php?filter=draft<?php echo $search ? '&search=' . urlencode($search) : ''; ?>">Draft</a></li>
                            <li><a class="dropdown-item <?php echo $filter === 'scheduled' ? 'active' : ''; ?>" href="memos.php?filter=scheduled<?php echo $search ? '&search=' . urlencode($search) : ''; ?>">Scheduled</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item <?php echo $filter === 'pending' ? 'active' : ''; ?>" href="memos.php?filter=pending<?php echo $search ? '&search=' . urlencode($search) : ''; ?>">Pending</a></li>
                            <li><a class="dropdown-item <?php echo $filter === 'acknowledged' ? 'active' : ''; ?>" href="memos.php?filter=acknowledged<?php echo $search ? '&search=' . urlencode($search) : ''; ?>">Acknowledged</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (count($memos) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <?php if (hasPermission('create_memo')): ?>
                                    <th>Status</th>
                                    <th>Recipients</th>
                                    <th>Acknowledged</th>
                                <?php else: ?>
                                    <th>From</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                <?php endif; ?>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($memos as $memo): ?>
                                <tr>
                                    <td><?php echo $memo['title']; ?></td>
                                    
                                    <?php if (hasPermission('create_memo')): ?>
                                        <td>
                                            <?php if ($memo['status'] === 'published'): ?>
                                                <span class="badge bg-success">Published</span>
                                            <?php elseif ($memo['status'] === 'draft'): ?>
                                                <span class="badge bg-secondary">Draft</span>
                                            <?php elseif ($memo['status'] === 'scheduled'): ?>
                                                <span class="badge bg-info">Scheduled</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo $memo['total_recipients']; ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="progress flex-grow-1 me-2" style="height: 5px;">
                                                    <div class="progress-bar bg-success" role="progressbar" 
                                                         style="width: <?php echo $memo['total_recipients'] > 0 ? ($memo['acknowledged'] / $memo['total_recipients']) * 100 : 0; ?>%" 
                                                         aria-valuenow="<?php echo $memo['acknowledged']; ?>" 
                                                         aria-valuemin="0" 
                                                         aria-valuemax="<?php echo $memo['total_recipients']; ?>"></div>
                                                </div>
                                                <span><?php echo $memo['acknowledged']; ?>/<?php echo $memo['total_recipients']; ?></span>
                                            </div>
                                        </td>
                                    <?php else: ?>
                                        <td><?php echo $memo['creator_name']; ?></td>
                                        <td><?php echo formatDate($memo['created_at']); ?></td>
                                        <td>
                                            <?php if ($memo['ack_status'] === 'acknowledged'): ?>
                                                <span class="badge bg-success">Acknowledged</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                    <?php endif; ?>
                                    
                                    <td>
                                        <a href="view_memo.php?id=<?php echo $memo['memo_id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        
                                        <?php if (hasPermission('create_memo') && $memo['status'] !== 'published'): ?>
                                            <a href="edit_memo.php?id=<?php echo $memo['memo_id']; ?>" class="btn btn-sm btn-info">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                            <button type="button" class="btn btn-sm btn-danger delete-memo" data-id="<?php echo $memo['memo_id']; ?>">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-center">No memos found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Memo Confirmation Modal -->
<div class="modal fade" id="deleteMemoModal" tabindex="-1" aria-labelledby="deleteMemoModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteMemoModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this memo? This action cannot be undone.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteMemoForm" method="POST" action="delete_memo.php">
                    <input type="hidden" name="memo_id" id="memoIdToDelete">
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Handle delete memo button click
    $('.delete-memo').click(function() {
        var memoId = $(this).data('id');
        $('#memoIdToDelete').val(memoId);
        $('#deleteMemoModal').modal('show');
    });
});
</script>

<?php
// Include footer
require_once 'footer.php';
?>