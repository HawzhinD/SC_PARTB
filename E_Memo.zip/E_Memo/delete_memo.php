<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Check if user has permission to create/delete memos
if (!hasPermission('create_memo')) {
    redirectWithMessage('memos.php', 'You do not have permission to delete memos', 'danger');
}

// Check if memo ID is provided
if (!isset($_POST['memo_id']) || !is_numeric($_POST['memo_id'])) {
    redirectWithMessage('memos.php', 'Invalid memo ID', 'danger');
}

$memoId = (int)$_POST['memo_id'];

// Get memo details
$memo = getMemoById($memoId);

// Check if memo exists
if (!$memo) {
    redirectWithMessage('memos.php', 'Memo not found', 'danger');
}

// Check if user is the creator of the memo
if ($memo['creator_id'] != $_SESSION['user_id']) {
    redirectWithMessage('memos.php', 'You can only delete memos you created', 'danger');
}

// Check if memo is in published state
if ($memo['status'] === 'published') {
    redirectWithMessage('memos.php', 'Published memos cannot be deleted', 'danger');
}

// Delete the memo
if (deleteMemo($memoId)) {
    redirectWithMessage('memos.php', 'Memo deleted successfully', 'success');
} else {
    redirectWithMessage('memos.php', 'Failed to delete memo. Please try again.', 'danger');
}