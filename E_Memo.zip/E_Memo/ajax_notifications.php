<?php
// Include necessary files
require_once 'config.php';
require_once 'functions.php';

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

// Check if the request is AJAX
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

// Get action
$action = isset($_POST['action']) ? sanitize($_POST['action']) : '';

// Handle different actions
switch ($action) {
    case 'mark_read':
        // Check if notification ID is provided
        if (!isset($_POST['notification_id']) || !is_numeric($_POST['notification_id'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
            exit;
        }
        
        $notificationId = (int)$_POST['notification_id'];
        
        // Check if the notification belongs to the current user
        $stmt = $pdo->prepare("SELECT user_id FROM notifications WHERE notification_id = ?");
        $stmt->execute([$notificationId]);
        $notification = $stmt->fetch();
        
        if (!$notification || $notification['user_id'] != $_SESSION['user_id']) {
            echo json_encode(['success' => false, 'message' => 'Notification not found or access denied']);
            exit;
        }
        
        // Mark notification as read
        if (markNotificationAsRead($notificationId)) {
            echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to mark notification as read']);
        }
        break;
        
    case 'send_reminders':
        // Check if memo ID is provided
        if (!isset($_POST['memo_id']) || !is_numeric($_POST['memo_id'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid memo ID']);
            exit;
        }
        
        $memoId = (int)$_POST['memo_id'];
        
        // Get memo details
        $memo = getMemoById($memoId);
        
        // Check if memo exists
        if (!$memo) {
            echo json_encode(['success' => false, 'message' => 'Memo not found']);
            exit;
        }
        
        // Check if user is the creator of the memo
        if ($memo['creator_id'] != $_SESSION['user_id']) {
            echo json_encode(['success' => false, 'message' => 'You can only send reminders for memos you created']);
            exit;
        }
        
        // Get recipients who haven't acknowledged the memo yet
        $stmt = $pdo->prepare("
            SELECT a.recipient_id 
            FROM acknowledgments a
            WHERE a.memo_id = ? AND a.status = 'not_acknowledged'
        ");
        $stmt->execute([$memoId]);
        $unacknowledgedRecipients = $stmt->fetchAll();
        
        if (empty($unacknowledgedRecipients)) {
            echo json_encode(['success' => false, 'message' => 'All recipients have already acknowledged this memo']);
            exit;
        }
        
        // Send reminders
        $remindersSent = 0;
        foreach ($unacknowledgedRecipients as $recipient) {
            createNotification(
                $recipient['recipient_id'],
                $memoId,
                'acknowledgment_reminder',
                "Reminder: Please acknowledge memo - {$memo['title']}"
            );
            $remindersSent++;
        }
        
        echo json_encode([
            'success' => true, 
            'message' => "Reminders sent to $remindersSent recipients",
            'reminder_count' => $remindersSent
        ]);
        break;
        
    case 'get_count':
        // Get unread notifications count
        $count = countUnreadNotifications($_SESSION['user_id']);
        echo json_encode(['success' => true, 'count' => $count]);
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}