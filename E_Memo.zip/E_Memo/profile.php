<?php
// Set page title
$pageTitle = 'My Profile';

// Include header
require_once 'header.php';

// Get current user
$user = getCurrentUser();

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Determine which form was submitted
    if (isset($_POST['update_profile'])) {
        // Update profile
        $fullName = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $department = sanitize($_POST['department'] ?? '');
        $position = sanitize($_POST['position'] ?? '');
        
        // Validate inputs
        $errors = [];
        
        if (empty($fullName)) {
            $errors[] = 'Full name is required';
        }
        
        if (empty($email)) {
            $errors[] = 'Email is required';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email format';
        } else {
            // Check if email already exists (excluding current user)
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ?");
            $stmt->execute([$email, $_SESSION['user_id']]);
            $count = $stmt->fetchColumn();
            
            if ($count > 0) {
                $errors[] = 'Email already exists';
            }
        }
        
        if (empty($errors)) {
            // Update user profile
            $stmt = $pdo->prepare("
                UPDATE users 
                SET full_name = ?, email = ?, department = ?, position = ? 
                WHERE user_id = ?
            ");
            
            if ($stmt->execute([$fullName, $email, $department, $position, $_SESSION['user_id']])) {
                // Update session variable
                $_SESSION['full_name'] = $fullName;
                
                // Log activity
                logActivity($_SESSION['user_id'], 'Update Profile', 'User updated their profile');
                
                $success = 'Profile updated successfully';
            } else {
                $errors[] = 'Failed to update profile. Please try again.';
            }
        }
    } elseif (isset($_POST['change_password'])) {
        // Change password
        $currentPassword = $_POST['current_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
        
        // Validate inputs
        $errors = [];
        
        if (empty($currentPassword)) {
            $errors[] = 'Current password is required';
        }
        
        if (empty($newPassword)) {
            $errors[] = 'New password is required';
        } elseif (strlen($newPassword) < 6) {
            $errors[] = 'New password must be at least 6 characters long';
        }
        
        if ($newPassword !== $confirmPassword) {
            $errors[] = 'New password and confirm password do not match';
        }
        
        if (empty($errors)) {
            // Verify current password
            $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $hash = $stmt->fetchColumn();
            
            if (password_verify($currentPassword, $hash)) {
                // Update password
                $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET password_hash = ? 
                    WHERE user_id = ?
                ");
                
                if ($stmt->execute([$newHash, $_SESSION['user_id']])) {
                    // Log activity
                    logActivity($_SESSION['user_id'], 'Change Password', 'User changed their password');
                    
                    $success = 'Password changed successfully';
                } else {
                    $errors[] = 'Failed to change password. Please try again.';
                }
            } else {
                $errors[] = 'Current password is incorrect';
            }
        }
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>My Profile</h1>
    </div>
    
    <?php if (isset($errors) && !empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-4">
            <!-- Profile Summary -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Profile Summary</h6>
                </div>
                <div class="card-body">
                    <div class="text-center mb-4">
                        <div style="width: 100px; height: 100px; background-color: #e9ecef; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto;">
                            <i class="fas fa-user fa-3x text-primary"></i>
                        </div>
                        <h5 class="mt-3"><?php echo $user['full_name']; ?></h5>
                        <p class="text-muted">
                            <?php echo $user['role_name']; ?>
                            <?php if ($user['department']): ?>
                                <br><?php echo $user['department']; ?>
                            <?php endif; ?>
                            <?php if ($user['position']): ?>
                                <br><?php echo $user['position']; ?>
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-envelope me-2"></i> Email</span>
                            <span class="text-muted"><?php echo $user['email']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-user me-2"></i> Username</span>
                            <span class="text-muted"><?php echo $user['username']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span><i class="fas fa-clock me-2"></i> Last Login</span>
                            <span class="text-muted"><?php echo $user['last_login'] ? formatDate($user['last_login']) : 'Never'; ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Activity Stats -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Activity Stats</h6>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <?php
                        // Get memo stats
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM memos WHERE creator_id = ?");
                        $stmt->execute([$_SESSION['user_id']]);
                        $createdMemos = $stmt->fetchColumn();
                        
                        $stmt = $pdo->prepare("
                            SELECT COUNT(*) FROM memo_recipients 
                            WHERE recipient_id = ?
                        ");
                        $stmt->execute([$_SESSION['user_id']]);
                        $receivedMemos = $stmt->fetchColumn();
                        
                        $stmt = $pdo->prepare("
                            SELECT COUNT(*) FROM acknowledgments 
                            WHERE recipient_id = ? AND status = 'acknowledged'
                        ");
                        $stmt->execute([$_SESSION['user_id']]);
                        $acknowledgedMemos = $stmt->fetchColumn();
                        ?>
                        
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Created Memos</span>
                            <span class="badge bg-primary rounded-pill"><?php echo $createdMemos; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Received Memos</span>
                            <span class="badge bg-primary rounded-pill"><?php echo $receivedMemos; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Acknowledged Memos</span>
                            <span class="badge bg-success rounded-pill"><?php echo $acknowledgedMemos; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <span>Pending Acknowledgments</span>
                            <span class="badge bg-warning rounded-pill"><?php echo $receivedMemos - $acknowledgedMemos; ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="col-lg-8">
            <!-- Update Profile -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Update Profile</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="full_name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" 
                                   value="<?php echo $user['full_name']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo $user['email']; ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="department" class="form-label">Department</label>
                            <input type="text" class="form-control" id="department" name="department" 
                                   value="<?php echo $user['department']; ?>">
                        </div>
                        
                        <div class="mb-3">
                            <label for="position" class="form-label">Position</label>
                            <input type="text" class="form-control" id="position" name="position" 
                                   value="<?php echo $user['position']; ?>">
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" name="update_profile" value="1" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Profile
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Change Password -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button" data-toggle="#current_password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button" data-toggle="#new_password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="form-text">Password must be at least 6 characters long.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button" data-toggle="#confirm_password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" name="change_password" value="1" class="btn btn-primary">
                                <i class="fas fa-lock"></i> Change Password
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once 'footer.php';
?>